﻿using AnimalNursery.Models.Animals;

namespace AnimalNursery.Services
{
    public interface IHomeFriendsRepository : IRepository<HomeFriend, int>
    {
    }
}
