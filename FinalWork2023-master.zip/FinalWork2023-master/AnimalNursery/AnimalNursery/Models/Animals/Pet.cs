﻿namespace AnimalNursery.Models.Animals
{
    public abstract class Pet : HomeFriend
    {
    }
}
