﻿namespace AnimalNursery.Models.Animals
{
    public abstract class PackAnimal : HomeFriend
    {
        public int LiftingWeight { get; set; }  
    }
}
