﻿namespace AnimalNursery.Models.Animals.ImpPets
{
    public class Hamster : Pet
    {
        public Hamster()
        {
            Type = "Hamster";

        }
    }
}
