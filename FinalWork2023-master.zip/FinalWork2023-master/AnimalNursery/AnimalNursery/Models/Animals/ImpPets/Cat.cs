﻿namespace AnimalNursery.Models.Animals.ImpPets
{
    public class Cat : Pet
    {
        public Cat() {
            Type = "Cat";

        }
    }
}
