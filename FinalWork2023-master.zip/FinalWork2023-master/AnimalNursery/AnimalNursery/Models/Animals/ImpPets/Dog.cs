﻿namespace AnimalNursery.Models.Animals.ImpPets
{
    public class Dog : Pet
    {
        public Dog()
        {
            Type = "Dog";

        }
    }
}
