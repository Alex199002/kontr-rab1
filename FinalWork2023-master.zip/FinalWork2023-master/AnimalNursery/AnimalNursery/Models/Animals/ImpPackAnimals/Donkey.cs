﻿namespace AnimalNursery.Models.Animals.ImpPackAnimals
{
    public class Donkey : PackAnimal
    {
        public Donkey() {
            Type = "Donkey";
        }
    }
}
