﻿namespace AnimalNursery.Models.Animals.ImpPackAnimals
{
    public class Horse : PackAnimal
    {
        public Horse()
        {
            Type = "Horse";
        }
    }
}
