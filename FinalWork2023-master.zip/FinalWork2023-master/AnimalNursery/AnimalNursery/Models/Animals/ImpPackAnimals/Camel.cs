﻿namespace AnimalNursery.Models.Animals.ImpPackAnimals
{
    public class Camel : PackAnimal
    {

       // public new string Type { get { return "Camel"; } }
        public Camel() {
            Type = "Camel";
        }  

    }
}
